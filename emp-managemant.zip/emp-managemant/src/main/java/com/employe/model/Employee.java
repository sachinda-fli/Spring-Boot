package com.employe.model;

public class Employee {
    String empNanme;
    String empLOcation;

    public String getEmpNanme() {
        return empNanme;
    }

    public void setEmpNanme(String empNanme) {
        this.empNanme = empNanme;
    }

    public String getEmpLOcation() {
        return empLOcation;
    }

    public void setEmpLOcation(String empLOcation) {
        this.empLOcation = empLOcation;
    }
}
