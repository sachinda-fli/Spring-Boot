package com.employe.service;

import com.employe.model.Employee;

import java.util.List;

public interface EmployeeService {

    List<Employee> getAllEmployees();
}
